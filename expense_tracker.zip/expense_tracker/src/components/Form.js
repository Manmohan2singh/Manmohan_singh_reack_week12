import React from 'react';
import Axios from 'axios';

const url ="http://localhost:8000/posts";
export default class Form extends React.Component{
    constructor(){
        super()
        this.initialState={
            payeeName:'',
            purchasedProduct:'',
            productPrice:'',
            productDate:null
        }
        this.state = this.initialState;
        this.handleChange = this.handleChange.bind(this);

        // var date_current = new Date();
        // var firstDay = new Date(date_current.getFullYear(), date_current.getMonth(), 1);
        // var lastDay = new Date(date_current.getFullYear(), date_current.getMonth() + 1, 0);

        // let date_element = document.getElementById("date");
        // date_element.setAttribute("min", firstDay);
        // date_element.setAttribute("max", lastDay);

       
    }
   
    handleChange(event) {
        event.preventDefault();
        const name = event.target.name;
        const value =  event.target.value;
        this.setState({
            [name]: value
          }); 
          console.log(this.state);      
      }

      handleSubmit(event) {        
        event.preventDefault();
        let payee_name =event.currentTarget[0].value
        let purchased_product =event.currentTarget[1].value
        let product_price =event.currentTarget[2].value
        let product_date =event.currentTarget[3].value

        Axios.post(url,{
            payeeName: payee_name,
            purchasedProduct: purchased_product,
            productPrice: product_price,
            productDate: product_date,
        });
        let cal_data = document.getElementById("cal_data");
        let pay_table = document.getElementById("pay_data");
        let row_table = pay_table.insertRow(-1);
        let pay_cell1 = row_table.insertCell(0);
        let pay_cell2 = row_table.insertCell(1);
        let pay_cell3 = row_table.insertCell(2);
        let pay_cell4 = row_table.insertCell(3);
        pay_cell1.innerHTML = payee_name;
        pay_cell2.innerHTML = purchased_product;
        pay_cell3.innerHTML = product_price;
        pay_cell4.innerHTML = product_date;

        // let cal_row = cal_data.insertRow(0);
        // let cal_cell1 = cal_row.insertCell(0);
        // let cal_cell2 = cal_row.insertCell(1);
        // cal_cell1.innerHTML = "TOTAL";
        // cal_cell2.innerHTML = purchased_product;

        // let f1_row = cal_data.insertRow(1);
        // let f1_cell1 = f1_row.insertCell(0);
        // let f1_cell2 = f1_row.insertCell(1);
        // f1_cell1.innerHTML = "Yash";
        // f1_cell2.innerHTML = purchased_product;

        // let f2_row = cal_data.insertRow(2);
        // let f2_cell1 = f2_row.insertCell(0);
        // let f2_cell2 = f2_row.insertCell(1);
        // f2_cell1.innerHTML = "Ashish";
        // f2_cell2.innerHTML = purchased_product;

        // let f3_row = cal_data.insertRow(3);
        // let f3_cell1 = f3_row.insertCell(0);
        // let f3_cell2 = f3_row.insertCell(1);
        // f3_cell1.innerHTML = "Mullu";
        // f3_cell2.innerHTML = purchased_product;

        // let f4_row = cal_data.insertRow(4);
        // let f4_cell1 = f4_row.insertCell(0);
        // let f4_cell2 = f4_row.insertCell(1);
        // f4_cell1.innerHTML = "Vikram";
        // f4_cell2.innerHTML = purchased_product;

      }
  
render(){
    return (
        <>
        <form action="" method="post" onSubmit={this.handleSubmit}>
            <div className="form-group">
                <label>Name*</label>
                <select name="payeeName" onChange={this.handleChange} value={this.state.payeeName}>
                    <option>Choose Payee</option>
                    <option value="Yash">Yash</option>
                    <option value="Ashish">Ashish</option>
                    <option value="Mullu">Mullu</option>
                    <option value="Vikram">Vikram</option>
                </select>
            </div>

            <div className="form-group">
                <label>Product Purchased</label>
                <input type="text" name="purchasedProduct" required="" onChange={this.handleChange} value={this.state.purchasedProduct}/>
            </div>

            <div className="form-group">
                <label>Product Price</label>
                <input type="number" name="productPrice" required="" onChange={this.handleChange} value={this.state.productPrice}/>
            </div>

            <div className="form-group">
                <label>Date</label>
                {/* <input type="date" id="date" name="productDate" min={firstDay} max={lastDay} onChange={this.handleChange} value={this.state.productDate}></input> */}
                <input type="date" name="productDate" id="date" required="" onChange={this.handleChange} value={this.state.productDate}/>
            </div>

            <input type="submit" value="submit" />
             <a className="close" href="#">Close</a>
        </form>
        </>
    );
}}